AddForceOnStart = {
	force_x = 300,
	force_y = -300,

	OnStart = function(self)
		self.rb = self.actor:GetComponent("Rigidbody")
		self.rb:AddForce(Vector2(self.force_x, self.force_y))
	end
}

